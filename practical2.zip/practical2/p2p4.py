animal = "elephant"

letter = animal[0]
print(letter)

letter = animal[1]
print(letter)

letter = animal[2]
print(letter)

letter = animal[3]
print(letter)

letter = animal[4]
print(letter)

letter = animal[5]
print(letter)

letter = animal[6]
print(letter)

letter = animal[7]
print(letter)