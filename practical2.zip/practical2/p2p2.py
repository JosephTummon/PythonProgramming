print("Hello," + " " + "world.")
