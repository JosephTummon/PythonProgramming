euro_amount = float(input("Enter euro amount to be converted to pounds: "))
if euro_amount < 0:
    print("Amount must be >= 0. Please try again")
    
if euro_amount >= 0:
    rate = 0.89 # Today's exchange rate
    pound_amount = round((rate * euro_amount), 2) #round to 2 decimal places
    print("€", euro_amount, " is £", pound_amount, sep="")