euro_amount = 222081.16
rate = 0.87
pound_amount = round((rate * euro_amount), 2) #round to 2 decimal places
print("€", euro_amount, " is £", pound_amount, sep="")